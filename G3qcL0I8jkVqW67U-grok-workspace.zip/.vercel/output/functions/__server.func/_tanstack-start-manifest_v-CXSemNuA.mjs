//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CXSemNuA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DKUt8lTt.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DKUt8lTt.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BHM6b0Hs.js"]
	}
} });
//#endregion
export { tsrStartManifest };
