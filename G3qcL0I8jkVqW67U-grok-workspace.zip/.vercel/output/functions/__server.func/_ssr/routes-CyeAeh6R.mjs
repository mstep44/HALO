import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as Bluetooth, _ as FileText, a as ThumbsDown, b as CheckCheck, c as Send, d as Mic, f as MapPin, g as Frown, h as Heart, i as ThumbsUp, l as Play, m as Laugh, n as Watch, o as Sparkles, p as Lock, s as Shield, t as X, u as Pause, v as ChevronLeft, x as Camera, y as Check } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CyeAeh6R.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var T0 = 176158e7;
var PHRASES = [
	"On my way",
	"Can't talk — text me",
	"Call you later",
	"Sounds good",
	"Running a few late",
	"Yes"
];
var CAMERA_ROLL = [
	{
		src: "/media/espresso.jpg",
		alt: "Espresso on a handlebar bag in morning light"
	},
	{
		src: "/media/ramen.jpg",
		alt: "Bowl of ramen on a dark wood table"
	},
	{
		src: "/media/trail.jpg",
		alt: "Mountain singletrack in late light"
	},
	{
		src: "/media/dog.jpg",
		alt: "Golden retriever on a sunlit porch"
	}
];
function msg(partial) {
	return {
		reactions: [],
		...partial
	};
}
function createSeed() {
	return [
		{
			id: "maya",
			name: "Maya Chen",
			monogram: "MC",
			phone: "+1 415 555 0142",
			rcs: true,
			e2ee: true,
			group: false,
			suggestions: [
				"On my way",
				"10 minutes",
				"Order for me"
			],
			typing: false,
			readAt: 176158004e4,
			messages: [
				msg({
					id: "m1",
					mine: false,
					text: "You still good for 7?",
					at: T0,
					clock: "6:28 PM",
					transport: "rcs"
				}),
				msg({
					id: "m2",
					mine: true,
					text: "Leaving the office now.",
					at: 176158004e4,
					clock: "6:31 PM",
					transport: "rcs",
					delivery: "read"
				}),
				msg({
					id: "m3",
					mine: false,
					text: "They held the corner table. This is the one you wanted.",
					media: {
						kind: "image",
						src: "/media/ramen.jpg",
						alt: "Bowl of spicy ramen"
					},
					at: 176158009e4,
					clock: "6:38 PM",
					transport: "rcs"
				}),
				msg({
					id: "m4",
					mine: false,
					text: "If you're late I'll order the spicy bowl.",
					at: 176158012e4,
					clock: "6:41 PM",
					transport: "rcs"
				})
			]
		},
		{
			id: "dad",
			name: "Dad",
			monogram: "DA",
			phone: "+1 503 555 0194",
			rcs: false,
			e2ee: false,
			group: false,
			suggestions: [],
			typing: false,
			readAt: 17615802e5,
			messages: [
				msg({
					id: "d1",
					mine: false,
					text: "Call when you land.",
					at: 176158001e4,
					clock: "4:12 PM",
					transport: "sms"
				}),
				msg({
					id: "d2",
					mine: true,
					text: "Will do.",
					at: 176158008e4,
					clock: "4:18 PM",
					transport: "sms",
					delivery: "sent"
				}),
				msg({
					id: "d3",
					mine: false,
					text: "Your mother says bring a jacket. It dropped to 40.",
					at: 17615802e5,
					clock: "5:02 PM",
					transport: "sms"
				})
			]
		},
		{
			id: "trail",
			name: "Trail crew",
			monogram: "TC",
			phone: "Group · 4",
			rcs: true,
			e2ee: true,
			group: true,
			members: "Jordan, Sam, Priya, you",
			suggestions: [
				"On my way",
				"Running late",
				"Start without me"
			],
			typing: false,
			readAt: 176158025e4,
			messages: [
				msg({
					id: "t1",
					mine: false,
					author: "Jordan",
					text: "Lot fills by 8. Park on the south edge.",
					media: {
						kind: "location",
						title: "Ridge trailhead",
						detail: "South lot · shared over RCS"
					},
					at: 176158023e4,
					clock: "5:46 PM",
					transport: "rcs"
				}),
				msg({
					id: "t2",
					mine: false,
					author: "Sam",
					text: "Dust is up but the singletrack is perfect.",
					media: {
						kind: "image",
						src: "/media/trail.jpg",
						alt: "Dirt trail through pines"
					},
					at: 176158026e4,
					clock: "5:51 PM",
					transport: "rcs"
				}),
				msg({
					id: "t3",
					mine: true,
					text: "Rolling in at 7:40.",
					at: 17615803e5,
					clock: "5:55 PM",
					transport: "rcs",
					delivery: "delivered"
				})
			]
		},
		{
			id: "alex",
			name: "Alex Rivera",
			monogram: "AR",
			phone: "+1 206 555 0177",
			rcs: true,
			e2ee: true,
			group: false,
			suggestions: [
				"Saturday works",
				"Tell him hi",
				"Send another"
			],
			typing: false,
			readAt: 176158031e4,
			messages: [msg({
				id: "a1",
				mine: false,
				media: {
					kind: "audio",
					seconds: 11
				},
				at: 176158032e4,
				clock: "3:14 PM",
				transport: "rcs"
			}), msg({
				id: "a2",
				mine: false,
				text: "He sat by the door for an hour.",
				media: {
					kind: "image",
					src: "/media/dog.jpg",
					alt: "Golden retriever on a porch"
				},
				at: 176158034e4,
				clock: "3:16 PM",
				transport: "rcs"
			})]
		},
		{
			id: "priya",
			name: "Priya Shah",
			monogram: "PS",
			phone: "+1 628 555 0118",
			rcs: true,
			e2ee: false,
			group: false,
			suggestions: [
				"I'll be there",
				"Running late",
				"Dial in"
			],
			typing: false,
			readAt: 176158035e4,
			messages: [msg({
				id: "p1",
				mine: false,
				card: {
					title: "Standup moved to 9:15",
					detail: "Dial-in stays the same. 12 minutes.",
					chips: [
						"I'll be there",
						"Running late",
						"Dial in"
					]
				},
				at: 176158036e4,
				clock: "8:02 AM",
				transport: "rcs"
			}), msg({
				id: "p2",
				mine: false,
				text: "Can you walk them through the wrist RCS flow?",
				at: 17615804e5,
				clock: "8:06 AM",
				transport: "rcs"
			})]
		}
	];
}
function previewOf(thread) {
	const last = thread.messages[thread.messages.length - 1];
	if (!last) return "No messages";
	if (thread.typing) return "Typing…";
	if (last.card) return last.card.title;
	if (last.media?.kind === "image") return last.text ? last.text : "Photo";
	if (last.media?.kind === "audio") return "Voice message";
	if (last.media?.kind === "location") return last.media.title;
	if (last.media?.kind === "file") return last.media.name;
	return last.text ?? "Message";
}
function unreadCount(thread) {
	return thread.messages.filter((m) => !m.mine && m.at > thread.readAt).length;
}
function clockNow(d = /* @__PURE__ */ new Date()) {
	let h = d.getHours();
	const m = d.getMinutes().toString().padStart(2, "0");
	const ap = h >= 12 ? "PM" : "AM";
	h = h % 12 || 12;
	return `${h}:${m} ${ap}`;
}
var seq = 0;
function nextId(prefix) {
	seq += 1;
	return `${prefix}-${seq}-${Math.random().toString(36).slice(2, 7)}`;
}
var epoch = 0;
var demoArmed = false;
var timers = /* @__PURE__ */ new Set();
function later(ms, fn, stamp) {
	const id = setTimeout(() => {
		timers.delete(id);
		if (stamp !== epoch) return;
		fn();
	}, ms);
	timers.add(id);
}
function clearTimers() {
	for (const id of timers) clearTimeout(id);
	timers.clear();
}
function patchThread(threads, id, fn) {
	return threads.map((t) => t.id === id ? fn(t) : t);
}
function patchMessage(threads, threadId, messageId, fn) {
	return patchThread(threads, threadId, (t) => ({
		...t,
		messages: t.messages.map((m) => m.id === messageId ? fn(m) : m)
	}));
}
function transportFor(thread, media) {
	if (!thread.rcs) return media ? "mms" : "sms";
	return "rcs";
}
var useHalo = create()(persist((set, get) => ({
	threads: createSeed(),
	screen: { name: "inbox" },
	focus: 0,
	banner: null,
	pulse: false,
	glance: false,
	device: "wrist",
	openThread: (id) => {
		const now = Date.now();
		set((s) => ({
			glance: false,
			pulse: false,
			banner: s.banner?.threadId === id ? null : s.banner,
			screen: {
				name: "thread",
				threadId: id
			},
			focus: Math.max(0, s.threads.findIndex((t) => t.id === id)),
			threads: patchThread(s.threads, id, (t) => ({
				...t,
				readAt: Math.max(t.readAt, now, ...t.messages.map((m) => m.at))
			}))
		}));
	},
	back: () => {
		const screen = get().screen;
		if (get().glance) {
			set({ glance: false });
			return;
		}
		if (screen.name === "photo") {
			set({ screen: {
				name: "thread",
				threadId: screen.threadId
			} });
			return;
		}
		if (screen.name === "thread") set({ screen: { name: "inbox" } });
	},
	moveFocus: (dir) => {
		const { threads, focus, screen } = get();
		if (screen.name !== "inbox") return;
		set({ focus: Math.min(threads.length - 1, Math.max(0, focus + dir)) });
	},
	openFocused: () => {
		const { threads, focus, screen } = get();
		if (screen.name !== "inbox") return;
		const thread = threads[focus];
		if (thread) get().openThread(thread.id);
	},
	openPhoto: (threadId, messageId) => set({
		screen: {
			name: "photo",
			threadId,
			messageId
		},
		glance: false
	}),
	sendText: (threadId, text, replyTo) => {
		const trimmed = text.trim();
		if (!trimmed) return;
		const thread = get().threads.find((t) => t.id === threadId);
		if (!thread) return;
		const id = nextId("out");
		const stamp = epoch;
		const message = {
			id,
			mine: true,
			text: trimmed,
			at: Date.now(),
			clock: clockNow(),
			transport: transportFor(thread, false),
			delivery: "sending",
			reactions: [],
			replyTo,
			fromWrist: true
		};
		set((s) => ({ threads: patchThread(s.threads, threadId, (t) => ({
			...t,
			suggestions: (t.suggestions ?? []).filter((c) => c !== trimmed),
			typing: false,
			readAt: message.at,
			messages: [...t.messages, message]
		})) }));
		scheduleDelivery(set, threadId, id, thread.rcs, stamp);
	},
	sendMedia: (threadId, media) => {
		const thread = get().threads.find((t) => t.id === threadId);
		if (!thread) return;
		const id = nextId("out");
		const stamp = epoch;
		const message = {
			id,
			mine: true,
			media,
			at: Date.now(),
			clock: clockNow(),
			transport: transportFor(thread, true),
			delivery: "sending",
			reactions: [],
			fromWrist: true
		};
		set((s) => ({ threads: patchThread(s.threads, threadId, (t) => ({
			...t,
			readAt: message.at,
			messages: [...t.messages, message]
		})) }));
		scheduleDelivery(set, threadId, id, thread.rcs, stamp);
	},
	react: (threadId, messageId, reaction) => {
		if (!get().threads.find((t) => t.id === threadId)?.rcs) return;
		set((s) => ({ threads: patchMessage(s.threads, threadId, messageId, (m) => {
			const has = m.reactions.includes(reaction);
			return {
				...m,
				reactions: has ? m.reactions.filter((r) => r !== reaction) : [...m.reactions, reaction]
			};
		}) }));
	},
	dismissBanner: () => set({
		banner: null,
		pulse: false
	}),
	setGlance: (open) => set({ glance: open }),
	setDevice: (device) => set({ device }),
	reset: () => {
		epoch += 1;
		clearTimers();
		demoArmed = false;
		set({
			threads: createSeed(),
			screen: { name: "inbox" },
			focus: 0,
			banner: null,
			pulse: false,
			glance: false
		});
		armDemo();
	}
}), {
	name: "halo-rcs-v1",
	skipHydration: true,
	partialize: (s) => ({
		threads: s.threads,
		screen: s.screen,
		focus: s.focus,
		device: s.device
	})
}));
function scheduleDelivery(set, threadId, messageId, rcs, stamp) {
	const steps = rcs ? [
		[320, "sent"],
		[900, "delivered"],
		[2400, "read"]
	] : [[480, "sent"]];
	for (const [ms, delivery] of steps) later(ms, () => {
		set((s) => ({ threads: patchMessage(s.threads, threadId, messageId, (m) => ({
			...m,
			delivery
		})) }));
	}, stamp);
}
function pushInbound(set, get, threadId, message) {
	const screen = get().screen;
	const viewing = screen.name !== "inbox" && "threadId" in screen && screen.threadId === threadId;
	set((s) => ({
		pulse: true,
		banner: viewing ? s.banner : {
			threadId,
			title: s.threads.find((t) => t.id === threadId)?.name ?? "Message",
			text: message.text ?? "New message"
		},
		threads: patchThread(s.threads, threadId, (t) => ({
			...t,
			typing: false,
			suggestions: threadId === "maya" ? [
				"I'll make it",
				"Order for me",
				"Running late"
			] : t.suggestions,
			readAt: viewing ? message.at : t.readAt,
			messages: [...t.messages, message]
		}))
	}));
	later(4600, () => {
		if (get().banner?.threadId === threadId) set(() => ({
			banner: null,
			pulse: false
		}));
	}, epoch);
}
function armDemo() {
	if (demoArmed || typeof window === "undefined") return;
	demoArmed = true;
	const stamp = epoch;
	const set = useHalo.setState;
	const get = useHalo.getState;
	const maya = get().threads.find((t) => t.id === "maya");
	if (maya?.messages.some((m) => m.id === "maya-live")) {
		if (maya.typing) set((s) => ({ threads: patchThread(s.threads, "maya", (t) => ({
			...t,
			typing: false
		})) }));
		return;
	}
	later(6500, () => {
		if (get().threads.find((t) => t.id === "maya")?.messages.some((m) => m.id === "maya-live")) return;
		set((s) => ({ threads: patchThread(s.threads, "maya", (t) => ({
			...t,
			typing: true
		})) }));
	}, stamp);
	later(9800, () => {
		if (get().threads.find((t) => t.id === "maya")?.messages.some((m) => m.id === "maya-live")) {
			set((s) => ({ threads: patchThread(s.threads, "maya", (t) => ({
				...t,
				typing: false
			})) }));
			return;
		}
		const message = {
			id: "maya-live",
			mine: false,
			text: "Kitchen closes at 9. If the train slips, text me and I'll order.",
			at: Date.now(),
			clock: clockNow(),
			transport: "rcs",
			reactions: []
		};
		pushInbound(set, get, "maya", message);
	}, stamp);
}
function totalUnread(threads) {
	return threads.reduce((n, t) => n + t.messages.filter((m) => !m.mine && m.at > t.readAt).length, 0);
}
var HardwareContext = (0, import_react.createContext)(null);
var noop = () => {};
function HardwareProvider({ children }) {
	const fire = (0, import_react.useRef)({
		up: noop,
		down: noop,
		start: noop,
		back: noop,
		light: noop
	});
	const setHandlers = (0, import_react.useMemo)(() => {
		return (h) => {
			fire.current = h;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			const typing = tag === "INPUT" || tag === "TEXTAREA";
			if (e.key === "Escape") {
				fire.current.back();
				e.preventDefault();
				return;
			}
			if (typing) return;
			if (e.key === "ArrowUp") {
				fire.current.up();
				e.preventDefault();
			} else if (e.key === "ArrowDown") {
				fire.current.down();
				e.preventDefault();
			} else if (e.key === "Enter") {
				fire.current.start();
				e.preventDefault();
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const value = (0, import_react.useMemo)(() => ({
		fire,
		setHandlers
	}), [setHandlers]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardwareContext.Provider, {
		value,
		children
	});
}
function useHardware(handlers) {
	const ctx = (0, import_react.useContext)(HardwareContext);
	const latest = (0, import_react.useRef)(handlers);
	latest.current = handlers;
	(0, import_react.useLayoutEffect)(() => {
		ctx?.setHandlers({
			up: () => latest.current.up(),
			down: () => latest.current.down(),
			start: () => latest.current.start(),
			back: () => latest.current.back(),
			light: () => latest.current.light()
		});
	});
}
function useHardwareFire() {
	const ctx = (0, import_react.useContext)(HardwareContext);
	if (!ctx) throw new Error("Hardware missing");
	return ctx.fire;
}
var REACTIONS = [
	{
		id: "like",
		label: "Like",
		Icon: ThumbsUp
	},
	{
		id: "love",
		label: "Love",
		Icon: Heart
	},
	{
		id: "laugh",
		label: "Laugh",
		Icon: Laugh
	},
	{
		id: "wow",
		label: "Wow",
		Icon: Sparkles
	},
	{
		id: "sad",
		label: "Sad",
		Icon: Frown
	},
	{
		id: "down",
		label: "Dislike",
		Icon: ThumbsDown
	}
];
function ReactionGlyph({ id, className }) {
	const found = REACTIONS.find((r) => r.id === id);
	if (!found) return null;
	const Icon = found.Icon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className,
		"aria-hidden": true
	});
}
var REACTION_LABEL = {
	like: "Like",
	love: "Love",
	laugh: "Laugh",
	wow: "Wow",
	sad: "Sad",
	down: "Dislike"
};
function deliveryLabel(message) {
	if (!message.mine) return message.clock;
	if (message.delivery === "sending") return "Sending";
	if (message.transport === "sms") return "Sent · SMS";
	if (message.transport === "mms") {
		if (message.delivery === "delivered") return "Delivered · MMS";
		if (message.delivery === "read") return "Read · MMS";
		return "Sent · MMS";
	}
	if (message.delivery === "read") return "Read";
	if (message.delivery === "delivered") return "Delivered";
	return "Sent · RCS";
}
function quoteText(thread, id) {
	if (!id) return null;
	const target = thread.messages.find((m) => m.id === id);
	if (!target) return null;
	if (target.text) return target.text;
	if (target.card) return target.card.title;
	if (target.media?.kind === "image") return "Photo";
	if (target.media?.kind === "audio") return "Voice message";
	if (target.media?.kind === "location") return target.media.title;
	if (target.media?.kind === "file") return target.media.name;
	return "Message";
}
function MessageBody({ thread, message, playing, onToggleAudio, onOpenImage, onChip, compact }) {
	const quote = quoteText(thread, message.replyTo);
	const mine = message.mine;
	const read = message.transport === "rcs" && message.delivery === "read";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex min-w-0 flex-col gap-1 ${mine ? "items-end" : "items-start"}`,
		children: [
			!mine && message.author ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-1 font-display text-xs tracking-wide text-signal uppercase",
				children: message.author
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `min-w-0 rounded-2xl px-3 py-2 text-ink ${mine ? "bubble-mine" : "bubble-theirs"}`,
				children: [
					quote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 truncate border-l-2 border-signal pl-2 text-xs text-dim",
						children: quote
					}) : null,
					message.card ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium text-pretty",
								children: message.card.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-pretty text-dim",
								children: message.card.detail
							}),
							message.card.chips.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex flex-wrap gap-1",
								children: message.card.chips.map((chip) => onChip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "min-h-11 rounded-full bg-line px-3 text-sm text-ink",
									onClick: (e) => {
										e.stopPropagation();
										onChip(chip);
									},
									children: chip
								}, chip) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "rounded-full bg-line px-2 py-1 text-xs text-ink",
									children: chip
								}, chip))
							}) : null
						]
					}) : null,
					message.media?.kind === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mb-1 block overflow-hidden rounded-xl",
						onClick: (e) => {
							e.stopPropagation();
							onOpenImage?.(message.id);
						},
						"aria-label": `View photo: ${message.media.alt}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: message.media.src,
							alt: message.media.alt,
							className: `w-full object-cover ${compact ? "h-28" : "h-40"}`
						})
					}) : null,
					message.media?.kind === "audio" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "mb-1 flex min-h-11 items-center gap-2 text-ink",
						onClick: (e) => {
							e.stopPropagation();
							onToggleAudio(message.id);
						},
						"aria-label": playing ? "Pause voice message" : "Play voice message",
						children: [
							playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4 shrink-0" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4 shrink-0" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `wave text-signal ${playing ? "" : "is-idle"}`,
								"aria-hidden": true,
								children: Array.from({ length: 14 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: { animationDelay: `${i % 5 * .08}s` } }, i))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs tabular-nums text-dim",
								children: ["0:", String(message.media.seconds).padStart(2, "0")]
							})
						]
					}) : null,
					message.media?.kind === "location" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-start gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
							className: "mt-0.5 size-4 shrink-0 text-signal",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: message.media.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-dim",
							children: message.media.detail
						})] })]
					}) : null,
					message.media?.kind === "file" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, {
							className: "size-4 shrink-0 text-signal",
							"aria-hidden": true
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: message.media.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs text-dim",
							children: message.media.size
						})] })]
					}) : null,
					message.text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-pretty",
						children: message.text
					}) : null
				]
			}),
			message.reactions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 px-1",
				children: message.reactions.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					title: REACTION_LABEL[id],
					className: "grid size-6 place-items-center rounded-full bg-line text-ink",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactionGlyph, {
						id,
						className: "size-3.5"
					})
				}, id))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: `flex items-center gap-1 px-1 text-xs tabular-nums ${read ? "text-signal" : "text-dim"}`,
				children: [
					message.fromWrist ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Watch, {
						className: "size-3",
						"aria-label": "Sent from the watch"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: deliveryLabel(message) }),
					message.mine && message.transport === "rcs" && message.delivery === "read" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, {
						className: "size-3.5",
						"aria-hidden": true
					}) : null,
					message.mine && message.transport === "rcs" && (message.delivery === "delivered" || message.delivery === "sent") ? message.delivery === "delivered" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, {
						className: "size-3.5",
						"aria-hidden": true
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "size-3.5",
						"aria-hidden": true
					}) : null,
					!message.mine ? null : message.transport === "sms" || message.transport === "mms" ? message.delivery !== "sending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
						className: "size-3.5",
						"aria-hidden": true
					}) : null : null
				]
			})
		]
	});
}
function Phone() {
	const threads = useHalo((s) => s.threads);
	const screen = useHalo((s) => s.screen);
	const focus = useHalo((s) => s.focus);
	const openThread = useHalo((s) => s.openThread);
	const activeId = screen.name === "inbox" ? threads[focus]?.id : screen.threadId;
	const thread = threads.find((t) => t.id === activeId) ?? threads[0];
	const scroller = (0, import_react.useRef)(null);
	const [playing, setPlaying] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (el) el.scrollTop = el.scrollHeight;
	}, [
		thread?.messages.length,
		thread?.id,
		thread?.typing
	]);
	if (!thread) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "phone-shell",
		"aria-label": "Paired handset",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-sm tracking-widest text-dim",
					children: "HANDSET"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-signal",
					children: "Pocket mode"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-3xl tracking-wide text-balance",
				children: thread.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-pretty text-dim",
				children: [
					thread.phone,
					" · ",
					thread.rcs ? "RCS chat synced with the watch" : "SMS chat · photos fall back to MMS"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "watch-scroll mt-3 flex gap-2 overflow-x-auto pb-1",
				children: threads.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-pressed": item.id === thread.id,
					className: `min-h-11 shrink-0 rounded-full px-3 text-sm ${item.id === thread.id ? "bg-signal text-oled" : "bg-line text-ink"}`,
					onClick: () => openThread(item.id),
					children: item.name
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				ref: scroller,
				className: "watch-scroll mt-2 flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto py-2",
				children: [thread.messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageBody, {
					thread,
					message,
					playing: playing === message.id,
					onToggleAudio: (id) => {
						if (playing === id) {
							setPlaying(null);
							return;
						}
						setPlaying(id);
						const seconds = message.media?.kind === "audio" ? message.media.seconds : 2;
						window.setTimeout(() => setPlaying((cur) => cur === id ? null : cur), seconds * 1e3);
					}
				}, message.id)), thread.typing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-signal",
					children: "Typing…"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "border-t border-line pt-3 text-sm text-pretty text-dim",
				children: [
					"The phone stays pocketed. Compose on the watch —",
					" ",
					thread.rcs ? "RCS carries read receipts, typing, and reactions." : "plain text goes as SMS, and voice or photos go as MMS."
				]
			})
		]
	});
}
function Monogram({ letters, hot }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `grid size-10 shrink-0 place-items-center rounded-full font-display text-sm tracking-wide ${hot ? "bg-signal text-oled" : "bg-line text-ink"}`,
		"aria-hidden": true,
		children: letters
	});
}
function ChannelPill({ thread }) {
	if (thread.rcs) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex shrink-0 items-center gap-1 font-display text-xs tracking-widest text-signal uppercase",
		children: [thread.e2ee ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
			className: "size-3",
			"aria-hidden": true
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
			className: "size-3",
			"aria-hidden": true
		}), "RCS"]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "shrink-0 font-display text-xs tracking-widest text-dim uppercase",
		children: "SMS"
	});
}
function Inbox() {
	const threads = useHalo((s) => s.threads);
	const focus = useHalo((s) => s.focus);
	const move = useHalo((s) => s.moveFocus);
	const openFocused = useHalo((s) => s.openFocused);
	const openThread = useHalo((s) => s.openThread);
	const back = useHalo((s) => s.back);
	const setGlance = useHalo((s) => s.setGlance);
	const glance = useHalo((s) => s.glance);
	const banner = useHalo((s) => s.banner);
	const items = (0, import_react.useRef)([]);
	useHardware({
		up: () => {
			if (!glance) move(-1);
		},
		down: () => {
			if (!glance) move(1);
		},
		start: () => {
			if (glance) return;
			if (banner) openThread(banner.threadId);
			else openFocused();
		},
		back,
		light: () => setGlance(!glance)
	});
	(0, import_react.useEffect)(() => {
		items.current[focus]?.scrollIntoView({ block: "nearest" });
	}, [focus]);
	const unread = totalUnread(threads);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-2 flex items-baseline justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl tracking-wide text-balance",
				children: "Messages"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-dim tabular-nums",
				children: unread ? `${unread} new` : "Clear"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "watch-scroll flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto",
			role: "listbox",
			"aria-label": "Conversations",
			children: threads.map((thread, index) => {
				const count = unreadCount(thread);
				const selected = index === focus;
				const last = thread.messages[thread.messages.length - 1];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					role: "option",
					"aria-selected": selected,
					ref: (el) => {
						items.current[index] = el;
					},
					onClick: () => openThread(thread.id),
					className: `flex min-h-11 items-center gap-2 rounded-2xl px-2 py-1 text-left ${selected ? "row-on" : ""}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monogram, {
						letters: thread.monogram,
						hot: count > 0
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-baseline justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `truncate font-medium ${count ? "text-ink" : "text-dim"}`,
								children: thread.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "shrink-0 text-xs text-dim tabular-nums",
								children: last?.clock
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-0.5 flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `truncate text-xs ${thread.typing ? "text-signal" : "text-dim"}`,
								children: previewOf(thread)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChannelPill, { thread })]
						})]
					})]
				}, thread.id);
			})
		})]
	});
}
function ThreadView({ threadId }) {
	const thread = useHalo((s) => s.threads.find((t) => t.id === threadId));
	const back = useHalo((s) => s.back);
	const sendText = useHalo((s) => s.sendText);
	const sendMedia = useHalo((s) => s.sendMedia);
	const react = useHalo((s) => s.react);
	const openPhoto = useHalo((s) => s.openPhoto);
	const glance = useHalo((s) => s.glance);
	const setGlance = useHalo((s) => s.setGlance);
	const [draft, setDraft] = (0, import_react.useState)("");
	const [replyTo, setReplyTo] = (0, import_react.useState)(null);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [mode, setMode] = (0, import_react.useState)("text");
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	const [playing, setPlaying] = (0, import_react.useState)(null);
	const scroller = (0, import_react.useRef)(null);
	const inputRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (mode !== "voice") return;
		const start = Date.now();
		const id = window.setInterval(() => {
			setElapsed(Math.max(1, Math.round((Date.now() - start) / 1e3)));
		}, 200);
		return () => window.clearInterval(id);
	}, [mode]);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (!el) return;
		el.scrollTop = el.scrollHeight;
	}, [
		thread?.messages.length,
		thread?.typing,
		mode
	]);
	const sendDraft = (text) => {
		if (!thread) return;
		sendText(thread.id, text, replyTo ?? void 0);
		setDraft("");
		setReplyTo(null);
		setSelected(null);
		setMode("text");
	};
	useHardware({
		up: () => {
			if (glance || mode !== "text") return;
			scroller.current?.scrollBy({
				top: -88,
				behavior: "smooth"
			});
		},
		down: () => {
			if (glance || mode !== "text") return;
			scroller.current?.scrollBy({
				top: 88,
				behavior: "smooth"
			});
		},
		start: () => {
			if (glance || !thread) return;
			if (mode === "voice") {
				sendMedia(thread.id, {
					kind: "audio",
					seconds: Math.max(1, elapsed)
				});
				setMode("text");
				setElapsed(0);
				return;
			}
			if (draft.trim()) sendDraft(draft);
			else inputRef.current?.focus();
		},
		back: () => {
			if (mode !== "text") {
				setMode("text");
				setElapsed(0);
				return;
			}
			if (selected) {
				setSelected(null);
				return;
			}
			if (replyTo) {
				setReplyTo(null);
				return;
			}
			back();
		},
		light: () => setGlance(!glance)
	});
	if (!thread) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col items-start justify-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-dim",
			children: "That conversation is gone."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "min-h-11 rounded-full bg-line px-4 text-sm",
			onClick: () => back(),
			children: "Back to messages"
		})]
	});
	const quoted = replyTo ? thread.messages.find((m) => m.id === replyTo) : void 0;
	const suggestions = thread.suggestions ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-1 flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "grid size-11 shrink-0 place-items-center rounded-full",
					onClick: () => back(),
					"aria-label": "Back to messages",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "truncate font-medium",
						children: thread.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-xs text-dim",
						children: [thread.rcs ? thread.e2ee ? "RCS · encrypted" : "RCS · Universal Profile" : "SMS · no read receipt", thread.members ? ` · ${thread.members}` : ""]
					})]
				})]
			}),
			mode === "voice" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Recorder, {
				thread,
				elapsed,
				onCancel: () => {
					setMode("text");
					setElapsed(0);
				},
				onSend: () => {
					sendMedia(thread.id, {
						kind: "audio",
						seconds: Math.max(1, elapsed)
					});
					setMode("text");
					setElapsed(0);
				}
			}) : null,
			mode === "roll" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-2 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display tracking-widest text-signal",
							children: thread.rcs ? "RCS FILE" : "MMS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 place-items-center",
							"aria-label": "Close camera roll",
							onClick: () => setMode("text"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-2 gap-2",
						children: CAMERA_ROLL.map((photo) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "overflow-hidden rounded-xl",
							onClick: () => {
								sendMedia(thread.id, {
									kind: "image",
									src: photo.src,
									alt: photo.alt
								});
								setMode("text");
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: photo.src,
								alt: photo.alt,
								className: "h-24 w-full object-cover"
							})
						}, photo.src))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-pretty text-dim",
						children: thread.rcs ? "High-resolution file transfer over RCS." : "This contact is SMS-only, so the photo sends as MMS."
					})
				]
			}) : null,
			mode === "phrases" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "watch-scroll flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display tracking-widest text-dim",
						children: "QUICK REPLY"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center",
						"aria-label": "Close phrases",
						onClick: () => setMode("text"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}), PHRASES.map((phrase) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-2xl bg-line px-3 text-left text-sm",
					onClick: () => sendDraft(phrase),
					children: phrase
				}, phrase))]
			}) : null,
			mode === "text" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					ref: scroller,
					className: "watch-scroll flex min-h-0 flex-1 flex-col gap-2 overflow-y-auto py-1",
					children: [thread.messages.map((message) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `rounded-2xl ${selected === message.id ? "is-picked" : ""}`,
						onClick: () => setSelected((cur) => cur === message.id ? null : message.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageBody, {
							thread,
							message,
							compact: true,
							playing: playing === message.id,
							onToggleAudio: (id) => {
								if (playing === id) {
									setPlaying(null);
									return;
								}
								setPlaying(id);
								const seconds = message.media?.kind === "audio" ? message.media.seconds : 2;
								window.setTimeout(() => setPlaying((cur) => cur === id ? null : cur), seconds * 1e3);
							},
							onOpenImage: (id) => openPhoto(thread.id, id),
							onChip: (chip) => sendDraft(chip)
						})
					}, message.id)), thread.typing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 text-xs text-signal",
						children: "Typing…"
					}) : null]
				}),
				selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "watch-scroll mb-1 flex gap-1 overflow-x-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 shrink-0 rounded-full bg-line px-3 text-sm",
						onClick: () => {
							setReplyTo(selected);
							setSelected(null);
							inputRef.current?.focus();
						},
						children: "Reply"
					}), thread.rcs ? REACTIONS.map((reaction) => {
						const Icon = reaction.Icon;
						const on = thread.messages.find((m) => m.id === selected)?.reactions.includes(reaction.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": reaction.label,
							"aria-pressed": on,
							className: `grid size-11 shrink-0 place-items-center rounded-full ${on ? "bg-signal text-oled" : "bg-line text-ink"}`,
							onClick: () => react(thread.id, selected, reaction.id),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
						}, reaction.id);
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "self-center px-2 text-xs text-dim",
						children: "Reactions need RCS"
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "watch-scroll mb-1 flex gap-1 overflow-x-auto",
					children: [(suggestions.length > 0 ? suggestions : PHRASES).map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 shrink-0 rounded-full bg-line px-3 text-sm",
						onClick: () => sendDraft(chip),
						children: chip
					}, chip)), suggestions.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 shrink-0 rounded-full bg-line px-3 text-sm text-dim",
						onClick: () => setMode("phrases"),
						children: "More"
					}) : null]
				}),
				quoted ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-1 flex items-center gap-2 text-xs text-dim",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1 truncate",
						children: ["Reply · ", quoted.text ?? "Attachment"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "grid size-11 place-items-center",
						"aria-label": "Cancel reply",
						onClick: () => setReplyTo(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex items-center gap-1",
					onSubmit: (e) => {
						e.preventDefault();
						if (draft.trim()) sendDraft(draft);
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 shrink-0 place-items-center rounded-full bg-line",
							"aria-label": "Record voice message",
							onClick: () => {
								setElapsed(0);
								setMode("voice");
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "grid size-11 shrink-0 place-items-center rounded-full bg-line",
							"aria-label": "Send a photo",
							onClick: () => setMode("roll"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: inputRef,
							value: draft,
							onChange: (e) => setDraft(e.target.value),
							placeholder: thread.rcs ? "RCS" : "SMS",
							"aria-label": thread.rcs ? "RCS reply" : "SMS reply",
							className: "h-11 min-w-0 flex-1 rounded-full bg-line px-3 text-base text-ink outline-none placeholder:text-dim"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "grid size-11 shrink-0 place-items-center rounded-full bg-signal text-oled disabled:opacity-40",
							disabled: !draft.trim(),
							"aria-label": "Send",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
						})
					]
				})
			] }) : null
		]
	});
}
function Recorder({ thread, elapsed, onCancel, onSend }) {
	const label = `0:${String(elapsed).padStart(2, "0")}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col items-center justify-center gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "wave text-signal",
				"aria-hidden": true,
				children: Array.from({ length: 16 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-5xl text-ink tabular-nums",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-xs text-pretty text-dim",
				children: thread.rcs ? "Voice note sends over RCS." : "Voice note sends as MMS."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-full bg-line px-4 text-sm",
					onClick: onCancel,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "min-h-11 rounded-full bg-signal px-4 text-sm font-medium text-oled",
					onClick: onSend,
					children: "Send"
				})]
			})
		]
	});
}
function Clock() {
	const [time, setTime] = (0, import_react.useState)("9:41");
	(0, import_react.useEffect)(() => {
		const tick = () => {
			const d = /* @__PURE__ */ new Date();
			let h = d.getHours();
			const m = String(d.getMinutes()).padStart(2, "0");
			h = h % 12 || 12;
			setTime(`${h}:${m}`);
		};
		tick();
		const id = window.setInterval(tick, 15e3);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-display text-lg text-ink tabular-nums",
		children: time
	});
}
function Glance() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glance-sheet absolute inset-0 z-20 flex flex-col gap-3 overflow-y-auto rounded-3xl pt-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl tracking-wide",
				children: "Phone link"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "space-y-3 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-display tracking-widest text-dim",
						children: "BLUETOOTH"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Connected to the handset" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-display tracking-widest text-signal",
						children: "RCS"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: "Registered · Universal Profile 2.7" })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-display tracking-widest text-dim",
						children: "SECURITY"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-pretty",
						children: "End-to-end encryption when the contact supports it"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "font-display tracking-widest text-alert",
						children: "FALLBACK"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-pretty",
						children: "SMS for text. MMS for photos and voice."
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-pretty text-dim",
				children: "Direct reply stays on the wrist. Receipts, typing, and reactions only travel when the thread is RCS."
			})
		]
	});
}
function Banner() {
	const banner = useHalo((s) => s.banner);
	const openThread = useHalo((s) => s.openThread);
	const dismiss = useHalo((s) => s.dismissBanner);
	if (!banner) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-x-0 top-8 z-10 flex items-stretch gap-1 rounded-2xl bg-line p-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "min-h-11 min-w-0 flex-1 px-2 text-left",
			onClick: () => openThread(banner.threadId),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "block font-display tracking-widest text-signal",
				children: ["RCS · ", banner.title]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block truncate text-sm",
				children: banner.text
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "grid size-11 shrink-0 place-items-center",
			"aria-label": "Dismiss notification",
			onClick: dismiss,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
		})]
	});
}
function PhotoView({ threadId, messageId }) {
	const thread = useHalo((s) => s.threads.find((t) => t.id === threadId));
	const back = useHalo((s) => s.back);
	const glance = useHalo((s) => s.glance);
	const setGlance = useHalo((s) => s.setGlance);
	const message = thread?.messages.find((m) => m.id === messageId);
	useHardware({
		up: () => {},
		down: () => {},
		start: () => back(),
		back,
		light: () => setGlance(!glance)
	});
	if (!message || message.media?.kind !== "image") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "min-h-11 text-sm text-dim",
		onClick: () => back(),
		children: "Close"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "mb-2 min-h-11 self-start text-sm text-dim",
				onClick: () => back(),
				children: "Close"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: message.media.src,
				alt: message.media.alt,
				className: "min-h-0 w-full flex-1 rounded-2xl object-cover"
			}),
			message.text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-pretty",
				children: message.text
			}) : null
		]
	});
}
function Watch$1() {
	const screen = useHalo((s) => s.screen);
	const pulse = useHalo((s) => s.pulse);
	const glance = useHalo((s) => s.glance);
	const setGlance = useHalo((s) => s.setGlance);
	const banner = useHalo((s) => s.banner);
	const fire = useHardwareFire();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "watch-rig",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "watch-bezel",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `watch-face ${pulse ? "is-pulse" : ""}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "watch-safe",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1 text-xs text-signal",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bluetooth, {
									className: "size-3.5",
									"aria-label": "Phone connected"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display tracking-widest",
									children: "RCS"
								})]
							})]
						}),
						screen.name === "inbox" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, {}) : null,
						screen.name !== "inbox" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: screen.name === "photo" ? "hidden" : "flex min-h-0 flex-1 flex-col",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThreadView, { threadId: screen.threadId })
						}) : null,
						screen.name === "photo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoView, {
							threadId: screen.threadId,
							messageId: screen.messageId
						}) : null,
						glance ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Glance, {}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "sr-only",
							"aria-live": "polite",
							children: banner ? `${banner.title}. ${banner.text}` : ""
						})
					]
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "watch-dock",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "hw hw-light",
					"aria-label": "Light, phone link",
					onClick: () => setGlance(!glance),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: "LIGHT"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "hw hw-up",
					"aria-label": "Up",
					onClick: () => fire.current.up(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: "UP"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "hw hw-down",
					"aria-label": "Down",
					onClick: () => fire.current.down(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: "DOWN"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "hw hw-back",
					"aria-label": "Back",
					onClick: () => fire.current.back(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: "BACK"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "hw hw-start",
					"aria-label": "Start",
					onClick: () => fire.current.start(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"aria-hidden": true,
						children: "START"
					})
				})
			]
		})]
	});
}
function HaloApp() {
	const device = useHalo((s) => s.device);
	const setDevice = useHalo((s) => s.setDevice);
	const reset = useHalo((s) => s.reset);
	const unread = totalUnread(useHalo((s) => s.threads));
	(0, import_react.useEffect)(() => {
		let cancel = false;
		Promise.resolve(useHalo.persist.rehydrate()).catch(() => void 0).then(() => {
			if (cancel) return;
			const state = useHalo.getState();
			if (!(Array.isArray(state.threads) && state.threads.length > 0 && state.threads.every((t) => Array.isArray(t.messages) && typeof t.rcs === "boolean"))) state.reset();
			else armDemo();
		});
		return () => {
			cancel = true;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HardwareProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex min-h-dvh w-full max-w-6xl flex-col overflow-x-hidden px-4 py-6 sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-5 flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-sm tracking-widest text-signal",
							children: "WRIST MESSENGER"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-5xl leading-none tracking-wide text-balance",
							children: "HALO"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-pretty text-dim",
							children: "Answer SMS, MMS, and RCS without taking the phone out. These are sample threads from a paired handset — anything you send leaves the watch immediately."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex rounded-full bg-line p-1 lg:hidden",
						role: "tablist",
						"aria-label": "Which device to show",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": device === "wrist",
							className: `min-h-11 rounded-full px-4 text-sm ${device === "wrist" ? "bg-face text-ink" : "text-dim"}`,
							onClick: () => setDevice("wrist"),
							children: "Wrist"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							role: "tab",
							"aria-selected": device === "handset",
							className: `min-h-11 rounded-full px-4 text-sm ${device === "handset" ? "bg-face text-ink" : "text-dim"}`,
							onClick: () => setDevice("handset"),
							children: "Handset"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "min-h-11 rounded-full px-3 text-sm text-dim",
						onClick: () => reset(),
						children: "Reset"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "sr-only",
				"aria-live": "polite",
				children: unread ? `${unread} unread` : "Inbox clear"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-6 lg:grid-cols-[minmax(0,36rem)_24rem] lg:justify-center lg:gap-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: device === "handset" ? "hidden lg:block" : "",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Watch$1, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: device === "wrist" ? "hidden lg:block" : "",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-center text-xs text-pretty text-dim",
				children: "UP and DOWN scroll. START opens or sends. BACK returns. LIGHT shows the phone link. On a wide screen the handset stays beside the watch."
			})
		]
	}) });
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloApp, {});
}
//#endregion
export { Home as component };
